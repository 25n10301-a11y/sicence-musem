과학의 발견 - 온라인 과학 박물관

구성 파일
- index.html : 웹페이지 구조
- style.css  : 다크 네이비 + 앤틱 골드 디자인
- script.js  : 전시 카드 생성 및 상세 설명 팝업 기능

실행 방법
1. 세 파일(index.html, style.css, script.js)을 같은 폴더에 둡니다.
2. index.html 파일을 더블 클릭하면 브라우저에서 열립니다.

GitHub Pages 배포
1. GitHub에서 새 저장소(repository)를 만듭니다.
2. 위 세 파일을 저장소 최상위 폴더에 업로드합니다.
3. Settings > Pages > Build and deployment에서 Deploy from a branch를 선택합니다.
4. Branch는 main, 폴더는 /(root)를 선택하고 Save를 누릅니다.
5. 잠시 기다리면 제공되는 주소로 사이트에 접속할 수 있습니다.
